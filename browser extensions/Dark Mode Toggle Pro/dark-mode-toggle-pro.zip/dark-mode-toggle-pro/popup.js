// Storage keys
const STORAGE_KEYS = {
    GLOBAL: 'darkModeGlobal',
    SITE_OVERRIDES: 'siteOverrides',
    PREMIUM: 'isPremium',
    AD_PREFERENCE: 'showAds'
};

// State
let currentTab = 'toggle';
let currentSite = null;
let currentSettings = {};

// Initialize on popup open
document.addEventListener('DOMContentLoaded', init);

async function init() {
    // Get current tab URL
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    currentSite = new URL(tab.url).hostname;

    // Load all settings
    await loadSettings();
    setupEventListeners();
    updateUI();
}

async function loadSettings() {
    const storage = await chrome.storage.sync.get(null);
    
    currentSettings = {
        global: storage[STORAGE_KEYS.GLOBAL] || getDefaultGlobalSettings(),
        siteOverrides: storage[STORAGE_KEYS.SITE_OVERRIDES] || {},
        isPremium: storage[STORAGE_KEYS.PREMIUM] || false,
        showAds: storage[STORAGE_KEYS.AD_PREFERENCE] !== false
    };
}

function getDefaultGlobalSettings() {
    return {
        darkModeEnabled: true,
        defaultFontSize: 100,
        defaultTextColor: '#e0e0e0',
        defaultBgColor: '#1a1a1a',
        theme: 'charcoal',
        syncEnabled: false,
        contrastLevel: 'normal'
    };
}

function setupEventListeners() {
    // Tab switching
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
            document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
            e.target.classList.add('active');
            currentTab = e.target.dataset.tab;
            document.getElementById(`${currentTab}-tab`).classList.add('active');
        });
    });

    // TOGGLE TAB
    const darkModeToggle = document.getElementById('darkModeToggle');
    darkModeToggle.addEventListener('change', toggleDarkMode);

    document.getElementById('resetBtn').addEventListener('click', resetSiteSettings);
    document.getElementById('globalToggleBtn').addEventListener('click', toggleGlobal);

    document.querySelectorAll('.preset-btn').forEach(btn => {
        btn.addEventListener('click', (e) => applyPreset(e.target.dataset.preset));
    });

    // ADJUST TAB
    document.getElementById('fontSizeSlider').addEventListener('input', updateFontSize);
    document.getElementById('lineHeightSlider').addEventListener('input', updateLineHeight);
    document.getElementById('textColorPicker').addEventListener('change', updateColors);
    document.getElementById('bgColorPicker').addEventListener('change', updateColors);
    document.getElementById('textColorPreset').addEventListener('change', (e) => {
        if (e.target.value) {
            document.getElementById('textColorPicker').value = rgbToHex(e.target.value);
            updateColors();
        }
    });
    document.getElementById('bgColorPreset').addEventListener('change', (e) => {
        if (e.target.value) {
            document.getElementById('bgColorPicker').value = rgbToHex(e.target.value);
            updateColors();
        }
    });

    document.querySelectorAll('.contrast-btn').forEach(btn => {
        btn.addEventListener('click', (e) => applyContrast(e.target.dataset.contrast));
    });

    // CSS TAB
    document.getElementById('cssTemplate').addEventListener('change', loadCSSTemplate);
    document.getElementById('previewCSSBtn').addEventListener('click', previewCSS);
    document.getElementById('saveCSSBtn').addEventListener('click', saveCSS);
    document.getElementById('clearCSSBtn').addEventListener('click', () => {
        document.getElementById('customCSS').value = '';
    });

    // SETTINGS TAB
    document.getElementById('syncEnabled').addEventListener('change', toggleSync);
    document.getElementById('adsDisabled').addEventListener('change', toggleAds);
    document.getElementById('premiumBtn').addEventListener('click', openPremium);
    document.getElementById('exportBtn').addEventListener('click', exportSettings);
    document.getElementById('importBtn').addEventListener('click', importSettings);
    document.getElementById('resetAllBtn').addEventListener('click', resetAllSettings);
}

function updateUI() {
    // Toggle tab
    const siteOverride = currentSettings.siteOverrides[currentSite];
    const isEnabled = siteOverride ? siteOverride.darkModeEnabled : currentSettings.global.darkModeEnabled;
    document.getElementById('darkModeToggle').checked = isEnabled;
    document.getElementById('siteStatus').textContent = `${isEnabled ? '✓' : '✗'} ${currentSite}`;

    // Adjust tab
    const fontSize = siteOverride?.defaultFontSize || currentSettings.global.defaultFontSize;
    const lineHeight = siteOverride?.lineHeight || 1.5;
    const textColor = siteOverride?.textColor || currentSettings.global.defaultTextColor;
    const bgColor = siteOverride?.bgColor || currentSettings.global.defaultBgColor;

    document.getElementById('fontSizeSlider').value = fontSize;
    document.getElementById('fontSizeValue').textContent = fontSize;
    document.getElementById('lineHeightSlider').value = lineHeight;
    document.getElementById('lineHeightValue').textContent = lineHeight.toFixed(1);
    document.getElementById('textColorPicker').value = hexToRgb(textColor) ? textColor : '#e0e0e0';
    document.getElementById('bgColorPicker').value = hexToRgb(bgColor) ? bgColor : '#1a1a1a';

    // CSS tab
    const customCSS = siteOverride?.customCSS || '';
    document.getElementById('customCSS').value = customCSS;

    // Settings tab
    document.getElementById('syncEnabled').checked = currentSettings.global.syncEnabled;
    document.getElementById('adsDisabled').checked = currentSettings.showAds;
}

async function toggleDarkMode() {
    const isEnabled = document.getElementById('darkModeToggle').checked;
    
    if (!currentSettings.siteOverrides[currentSite]) {
        currentSettings.siteOverrides[currentSite] = {};
    }
    
    currentSettings.siteOverrides[currentSite].darkModeEnabled = isEnabled;
    
    await saveSettings();
    await injectStyles();
    updateUI();
}

async function resetSiteSettings() {
    if (confirm('Reset dark mode settings for this site?')) {
        delete currentSettings.siteOverrides[currentSite];
        await saveSettings();
        await injectStyles();
        updateUI();
    }
}

async function toggleGlobal() {
    currentSettings.global.darkModeEnabled = !currentSettings.global.darkModeEnabled;
    await saveSettings();
    await injectStyles();
    updateUI();
}

async function applyPreset(preset) {
    if (!currentSettings.siteOverrides[currentSite]) {
        currentSettings.siteOverrides[currentSite] = {};
    }

    switch(preset) {
        case 'light':
            currentSettings.siteOverrides[currentSite].darkModeEnabled = false;
            break;
        case 'dark':
            currentSettings.siteOverrides[currentSite].darkModeEnabled = true;
            break;
        case 'auto':
            delete currentSettings.siteOverrides[currentSite].darkModeEnabled;
            break;
    }

    await saveSettings();
    await injectStyles();
    updateUI();
}

function updateFontSize() {
    const value = document.getElementById('fontSizeSlider').value;
    document.getElementById('fontSizeValue').textContent = value;
    
    if (!currentSettings.siteOverrides[currentSite]) {
        currentSettings.siteOverrides[currentSite] = {};
    }
    currentSettings.siteOverrides[currentSite].defaultFontSize = parseInt(value);
}

function updateLineHeight() {
    const value = document.getElementById('lineHeightSlider').value;
    document.getElementById('lineHeightValue').textContent = parseFloat(value).toFixed(1);
    
    if (!currentSettings.siteOverrides[currentSite]) {
        currentSettings.siteOverrides[currentSite] = {};
    }
    currentSettings.siteOverrides[currentSite].lineHeight = parseFloat(value);
}

function updateColors() {
    const textColor = document.getElementById('textColorPicker').value;
    const bgColor = document.getElementById('bgColorPicker').value;
    
    if (!currentSettings.siteOverrides[currentSite]) {
        currentSettings.siteOverrides[currentSite] = {};
    }
    
    currentSettings.siteOverrides[currentSite].textColor = textColor;
    currentSettings.siteOverrides[currentSite].bgColor = bgColor;
    
    saveSettings();
}

async function applyContrast(level) {
    if (!currentSettings.siteOverrides[currentSite]) {
        currentSettings.siteOverrides[currentSite] = {};
    }
    
    currentSettings.siteOverrides[currentSite].contrastLevel = level;
    
    const contrastMap = {
        normal: { text: '#e0e0e0', bg: '#1a1a1a' },
        high: { text: '#ffffff', bg: '#000000' },
        low: { text: '#b0b0b0', bg: '#2a2a2a' }
    };
    
    const { text, bg } = contrastMap[level];
    document.getElementById('textColorPicker').value = text;
    document.getElementById('bgColorPicker').value = bg;
    
    updateColors();
    
    document.querySelectorAll('.contrast-btn').forEach(btn => {
        btn.classList.toggle('active', btn.dataset.contrast === level);
    });
    
    await saveSettings();
}

function loadCSSTemplate() {
    const template = document.getElementById('cssTemplate').value;
    const templates = {
        youtube: `/* Hide YouTube distractions */
.ytp-gradient-top { display: none !important; }
.yt-spec-shelf { background-color: #0f0f0f !important; }`,
        reddit: `/* Reddit dark mode fix */
.Post { background-color: #1a1a1b !important; }
.Comment { background-color: #030303 !important; }`,
        github: `/* GitHub optimization */
.Box-row { background-color: #0d1117 !important; border-color: #30363d !important; }`,
        google: `/* Google Search dark */
.g { color: #e8e8e8 !important; }`
    };
    
    if (templates[template]) {
        document.getElementById('customCSS').value = templates[template];
    }
}

function previewCSS() {
    const css = document.getElementById('customCSS').value;
    injectCustomCSS(css, true);
    showStatus('Preview applied (changes not saved)', 'success');
}

async function saveCSS() {
    const css = document.getElementById('customCSS').value;
    
    if (!isValidCSS(css)) {
        showStatus('Invalid CSS syntax', 'error');
        return;
    }
    
    if (!currentSettings.siteOverrides[currentSite]) {
        currentSettings.siteOverrides[currentSite] = {};
    }
    
    currentSettings.siteOverrides[currentSite].customCSS = css;
    
    await saveSettings();
    await injectCustomCSS(css, false);
    showStatus('CSS saved successfully', 'success');
}

function isValidCSS(css) {
    try {
        new CSSStyleSheet();
        return true;
    } catch {
        return false;
    }
}

async function toggleSync() {
    currentSettings.global.syncEnabled = document.getElementById('syncEnabled').checked;
    if (!currentSettings.isPremium) {
        showStatus('Premium feature', 'error');
        document.getElementById('syncEnabled').checked = false;
        return;
    }
    await saveSettings();
}

function toggleAds() {
    currentSettings.showAds = document.getElementById('adsDisabled').checked;
    saveSettings();
}

function openPremium() {
    // In real app, open Stripe/Paddle payment
    alert('Premium upgrade:\n✓ 5 Professional Themes\n✓ Unlimited Custom CSS\n✓ Cloud Sync\n✓ Advanced Controls\n✓ Ad-Free\n\n$1.99/month');
}

function exportSettings() {
    const data = JSON.stringify(currentSettings, null, 2);
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'darkmode-settings.json';
    a.click();
}

function importSettings() {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json';
    input.onchange = async (e) => {
        const file = e.target.files[0];
        const text = await file.text();
        try {
            const imported = JSON.parse(text);
            currentSettings = imported;
            await saveSettings();
            updateUI();
            showStatus('Settings imported', 'success');
        } catch {
            showStatus('Invalid file', 'error');
        }
    };
    input.click();
}

async function resetAllSettings() {
    if (confirm('Reset all settings? This cannot be undone.')) {
        await chrome.storage.sync.clear();
        currentSettings = {
            global: getDefaultGlobalSettings(),
            siteOverrides: {},
            isPremium: false,
            showAds: true
        };
        updateUI();
        showStatus('All settings reset', 'success');
    }
}

function showStatus(message, type) {
    const statusEl = document.getElementById('cssStatus');
    statusEl.textContent = message;
    statusEl.className = `status-message ${type}`;
    setTimeout(() => {
        statusEl.className = 'status-message';
        statusEl.textContent = '';
    }, 3000);
}

async function injectStyles() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    await chrome.tabs.sendMessage(tab.id, {
        action: 'applyStyles',
        settings: currentSettings,
        site: currentSite
    }).catch(() => {});
}

async function injectCustomCSS(css, isPreview) {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    await chrome.tabs.sendMessage(tab.id, {
        action: 'injectCSS',
        css: css,
        isPreview: isPreview
    }).catch(() => {});
}

async function saveSettings() {
    await chrome.storage.sync.set({
        [STORAGE_KEYS.GLOBAL]: currentSettings.global,
        [STORAGE_KEYS.SITE_OVERRIDES]: currentSettings.siteOverrides,
        [STORAGE_KEYS.PREMIUM]: currentSettings.isPremium,
        [STORAGE_KEYS.AD_PREFERENCE]: currentSettings.showAds
    });
}

function hexToRgb(hex) {
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result ? {
        r: parseInt(result[1], 16),
        g: parseInt(result[2], 16),
        b: parseInt(result[3], 16)
    } : null;
}

function rgbToHex(rgb) {
    if (!rgb || !rgb.startsWith('#')) return rgb;
    return rgb;
}
