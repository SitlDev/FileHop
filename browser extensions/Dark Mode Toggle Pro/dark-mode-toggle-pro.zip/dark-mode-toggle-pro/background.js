// Background service worker for Dark Mode Toggle Pro

// Initialize on install
chrome.runtime.onInstalled.addListener((details) => {
    if (details.reason === 'install') {
        // Set default values
        chrome.storage.sync.get(null, (storage) => {
            if (!storage.darkModeGlobal) {
                chrome.storage.sync.set({
                    darkModeGlobal: {
                        darkModeEnabled: true,
                        defaultFontSize: 100,
                        defaultTextColor: '#e0e0e0',
                        defaultBgColor: '#1a1a1a',
                        theme: 'charcoal',
                        syncEnabled: false,
                        contrastLevel: 'normal'
                    },
                    siteOverrides: {},
                    isPremium: false,
                    showAds: true
                });
            }
        });
    }
});

// Context menu setup
chrome.runtime.onInstalled.addListener(() => {
    chrome.contextMenus.create({
        id: 'toggleDarkMode',
        title: 'Toggle Dark Mode',
        contexts: ['page']
    });
    
    chrome.contextMenus.create({
        id: 'toggleDarkModeSeparator',
        type: 'separator',
        contexts: ['page']
    });
    
    chrome.contextMenus.create({
        id: 'openSettings',
        title: 'Open Dark Mode Settings',
        contexts: ['page']
    });
});

// Handle context menu clicks
chrome.contextMenus.onClicked.addListener((info, tab) => {
    if (info.menuItemId === 'toggleDarkMode') {
        toggleDarkModeForTab(tab);
    } else if (info.menuItemId === 'openSettings') {
        chrome.action.openPopup();
    }
});

async function toggleDarkModeForTab(tab) {
    const site = new URL(tab.url).hostname;
    
    // Get current settings
    const storage = await chrome.storage.sync.get(null);
    const siteOverrides = storage.siteOverrides || {};
    
    if (!siteOverrides[site]) {
        siteOverrides[site] = {};
    }
    
    // Toggle the state
    const currentState = siteOverrides[site].darkModeEnabled;
    siteOverrides[site].darkModeEnabled = currentState === false ? true : false;
    
    // Save and apply
    await chrome.storage.sync.set({ siteOverrides });
    
    // Inject into tab
    const message = {
        action: 'applyStyles',
        settings: {
            global: storage.darkModeGlobal,
            siteOverrides: siteOverrides,
            isPremium: storage.isPremium
        },
        site: site
    };
    
    try {
        await chrome.tabs.sendMessage(tab.id, message);
    } catch (err) {
        console.log('Content script not loaded, will apply on reload');
    }
    
    // Update badge
    updateBadge(tab.id, siteOverrides[site].darkModeEnabled);
}

function updateBadge(tabId, isEnabled) {
    if (isEnabled) {
        chrome.action.setBadgeText({ text: '✓', tabId });
        chrome.action.setBadgeBackgroundColor({ color: '#7c3aed', tabId });
    } else {
        chrome.action.setBadgeText({ text: '', tabId });
    }
}

// Update badge when tab changes
chrome.tabs.onActivated.addListener(async (activeInfo) => {
    const tab = await chrome.tabs.get(activeInfo.tabId);
    const site = new URL(tab.url).hostname;
    
    const storage = await chrome.storage.sync.get(null);
    const siteOverrides = storage.siteOverrides || {};
    const isEnabled = siteOverrides[site]?.darkModeEnabled ?? storage.darkModeGlobal?.darkModeEnabled;
    
    updateBadge(tab.id, isEnabled);
});

// Keyboard shortcut handler
chrome.commands.onCommand.addListener(async (command) => {
    if (command === '_execute_action') {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        toggleDarkModeForTab(tab);
    }
});

// Handle messages from content script
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'updateBadge') {
        updateBadge(sender.tab.id, request.isEnabled);
    }
});

// Analytics tracking (optional - for free vs premium split)
function trackEvent(category, action, label, value) {
    // In production, send to Mixpanel, Segment, etc.
    console.log(`Event: ${category} > ${action}`, { label, value });
}

// Check if user is premium and log it
chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName === 'sync' && changes.isPremium) {
        trackEvent('Settings', 'Premium Activated', '', changes.isPremium.newValue);
    }
});
