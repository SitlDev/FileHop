// Dark mode content script
let currentSettings = {};
let styleInjected = false;

// Initialize on page load
chrome.storage.sync.get(null, (storage) => {
    currentSettings = {
        global: storage.darkModeGlobal || getDefaultGlobalSettings(),
        siteOverrides: storage.siteOverrides || {},
        isPremium: storage.isPremium || false
    };
    
    const site = new URL(window.location.href).hostname;
    const siteSettings = currentSettings.siteOverrides[site];
    const shouldEnable = siteSettings?.darkModeEnabled ?? currentSettings.global.darkModeEnabled;
    
    if (shouldEnable) {
        applyDarkMode();
    }
    
    if (siteSettings?.customCSS) {
        injectCustomCSS(siteSettings.customCSS);
    }
});

// Listen for messages from popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'applyStyles') {
        currentSettings = request.settings;
        const site = request.site;
        const siteSettings = currentSettings.siteOverrides[site];
        const shouldEnable = siteSettings?.darkModeEnabled ?? currentSettings.global.darkModeEnabled;
        
        if (shouldEnable) {
            applyDarkMode();
        } else {
            removeDarkMode();
        }
        sendResponse({ status: 'styles applied' });
    }
    
    if (request.action === 'injectCSS') {
        injectCustomCSS(request.css);
        sendResponse({ status: 'css injected' });
    }
});

function getDefaultGlobalSettings() {
    return {
        darkModeEnabled: true,
        defaultFontSize: 100,
        defaultTextColor: '#e0e0e0',
        defaultBgColor: '#1a1a1a',
        theme: 'charcoal',
        contrastLevel: 'normal'
    };
}

function applyDarkMode() {
    const site = new URL(window.location.href).hostname;
    const siteSettings = currentSettings.siteOverrides[site] || {};
    
    const fontSize = siteSettings.defaultFontSize || currentSettings.global.defaultFontSize;
    const lineHeight = siteSettings.lineHeight || 1.5;
    const textColor = siteSettings.textColor || currentSettings.global.defaultTextColor;
    const bgColor = siteSettings.bgColor || currentSettings.global.defaultBgColor;
    
    // Remove existing dark mode style
    const existingStyle = document.getElementById('dark-mode-style');
    if (existingStyle) {
        existingStyle.remove();
    }
    
    // Create and inject dark mode CSS
    const style = document.createElement('style');
    style.id = 'dark-mode-style';
    style.textContent = generateDarkModeCSS(fontSize, lineHeight, textColor, bgColor, siteSettings.contrastLevel);
    
    // Inject into document head (or shadow DOM if needed)
    if (document.head) {
        document.head.appendChild(style);
    } else {
        document.documentElement.appendChild(style);
    }
    
    styleInjected = true;
    
    // Apply to dynamically loaded content
    observeDOMChanges();
}

function removeDarkMode() {
    const style = document.getElementById('dark-mode-style');
    if (style) {
        style.remove();
    }
    styleInjected = false;
}

function generateDarkModeCSS(fontSize, lineHeight, textColor, bgColor, contrastLevel) {
    const css = `
        /* Dark Mode Toggle Pro - Auto-generated */
        
        /* Root elements */
        html, body {
            background-color: ${bgColor} !important;
            color: ${textColor} !important;
            font-size: ${fontSize}% !important;
            line-height: ${lineHeight} !important;
        }
        
        /* Text elements */
        p, span, div, li, td, th, h1, h2, h3, h4, h5, h6, a, label {
            color: ${textColor} !important;
            background-color: transparent !important;
        }
        
        /* Links */
        a {
            color: #6b9fff !important;
            text-decoration: underline !important;
        }
        
        a:visited {
            color: #9b6fff !important;
        }
        
        /* Backgrounds and surfaces */
        main, article, section, nav, header, footer, .container, .content,
        [role="main"], [role="contentinfo"], [role="navigation"] {
            background-color: ${bgColor} !important;
            color: ${textColor} !important;
        }
        
        /* Cards and panels */
        .card, .panel, .box, .widget, .post, .item, article {
            background-color: ${shadeColor(bgColor, 10)} !important;
            color: ${textColor} !important;
            border-color: ${shadeColor(bgColor, 20)} !important;
        }
        
        /* Forms and inputs */
        input, textarea, select, button {
            background-color: ${shadeColor(bgColor, 5)} !important;
            color: ${textColor} !important;
            border-color: ${shadeColor(bgColor, 20)} !important;
        }
        
        input::placeholder, textarea::placeholder {
            color: ${adjustBrightness(textColor, -30)} !important;
        }
        
        /* Buttons */
        button, [role="button"], input[type="button"], input[type="submit"] {
            background-color: #6b7280 !important;
            color: ${textColor} !important;
            border-color: #4b5563 !important;
        }
        
        button:hover, [role="button"]:hover {
            background-color: #7b8390 !important;
        }
        
        /* Code blocks */
        code, pre {
            background-color: ${shadeColor(bgColor, 15)} !important;
            color: #e0e0e0 !important;
            border-color: ${shadeColor(bgColor, 25)} !important;
        }
        
        /* Tables */
        table, th, td {
            border-color: ${shadeColor(bgColor, 20)} !important;
            background-color: transparent !important;
        }
        
        th {
            background-color: ${shadeColor(bgColor, 10)} !important;
            color: ${textColor} !important;
        }
        
        /* Images - preserve colors */
        img, video, iframe, canvas {
            /* Do not invert */
            filter: none !important;
        }
        
        /* Scrollbars */
        ::-webkit-scrollbar {
            background-color: ${bgColor} !important;
        }
        
        ::-webkit-scrollbar-track {
            background-color: ${shadeColor(bgColor, 10)} !important;
        }
        
        ::-webkit-scrollbar-thumb {
            background-color: ${shadeColor(bgColor, 30)} !important;
        }
        
        ::-webkit-scrollbar-thumb:hover {
            background-color: ${shadeColor(bgColor, 40)} !important;
        }
        
        /* Selectable text */
        ::selection {
            background-color: #6b7280 !important;
            color: ${textColor} !important;
        }
        
        /* Context menus */
        .context-menu, .dropdown, .popover, .tooltip {
            background-color: ${shadeColor(bgColor, 10)} !important;
            color: ${textColor} !important;
            border-color: ${shadeColor(bgColor, 20)} !important;
        }
        
        /* Remove background images that might be light */
        body, html, main, .container, [role="main"] {
            background-image: none !important;
        }
        
        /* Preserve visibility of essential elements */
        svg, [role="img"] {
            filter: none !important;
        }
    `;
    
    return css;
}

function injectCustomCSS(css) {
    const site = new URL(window.location.href).hostname;
    
    // Remove existing custom CSS
    const existingCustom = document.getElementById('custom-css-style');
    if (existingCustom) {
        existingCustom.remove();
    }
    
    // Inject custom CSS
    const style = document.createElement('style');
    style.id = 'custom-css-style';
    style.textContent = css;
    
    if (document.head) {
        document.head.appendChild(style);
    } else {
        document.documentElement.appendChild(style);
    }
}

function shadeColor(color, percent) {
    const num = parseInt(color.replace("#", ""), 16);
    const amt = Math.round(2.55 * percent);
    const R = (num >> 16) + amt;
    const G = (num >> 8 & 0x00FF) + amt;
    const B = (num & 0x0000FF) + amt;
    return "#" + (
        0x1000000 + (R < 255 ? R < 1 ? 0 : R : 255) * 0x10000 +
        (G < 255 ? G < 1 ? 0 : G : 255) * 0x100 +
        (B < 255 ? B < 1 ? 0 : B : 255)
    ).toString(16).slice(1);
}

function adjustBrightness(color, percent) {
    const num = parseInt(color.replace("#", ""), 16);
    const amt = Math.round(2.55 * percent);
    const R = Math.max(0, Math.min(255, (num >> 16) + amt));
    const G = Math.max(0, Math.min(255, (num >> 8 & 0x00FF) + amt));
    const B = Math.max(0, Math.min(255, (num & 0x0000FF) + amt));
    return "#" + (
        0x1000000 + R * 0x10000 + G * 0x100 + B
    ).toString(16).slice(1);
}

function observeDOMChanges() {
    if (typeof MutationObserver === 'undefined') return;
    
    const observer = new MutationObserver((mutations) => {
        // Reapply dark mode to new nodes
        if (styleInjected) {
            mutations.forEach((mutation) => {
                mutation.addedNodes.forEach((node) => {
                    if (node.nodeType === 1) { // Element node
                        ensureDarkModeOnNode(node);
                    }
                });
            });
        }
    });
    
    observer.observe(document.body || document.documentElement, {
        childList: true,
        subtree: true
    });
}

function ensureDarkModeOnNode(node) {
    // Ensure new content respects dark mode
    // This is handled by the injected CSS via !important flags
}

// Listen for context menu (right-click)
document.addEventListener('contextmenu', (e) => {
    // Will be handled by background.js
});
